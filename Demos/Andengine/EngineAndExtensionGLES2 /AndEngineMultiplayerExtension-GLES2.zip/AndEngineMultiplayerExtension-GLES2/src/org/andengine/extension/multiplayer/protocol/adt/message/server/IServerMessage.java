package org.andengine.extension.multiplayer.protocol.adt.message.server;

import org.andengine.extension.multiplayer.protocol.adt.message.IMessage;

/**
 * (c) 2010 Nicolas Gramlich 
 * (c) 2011 Zynga Inc.
 * 
 * @author Nicolas Gramlich
 * @since 18:15:42 - 18.09.2009
 */
public interface IServerMessage extends IMessage {
	// ===========================================================
	// Final Fields
	// ===========================================================

	// ===========================================================
	// Methods
	// ===========================================================
}
