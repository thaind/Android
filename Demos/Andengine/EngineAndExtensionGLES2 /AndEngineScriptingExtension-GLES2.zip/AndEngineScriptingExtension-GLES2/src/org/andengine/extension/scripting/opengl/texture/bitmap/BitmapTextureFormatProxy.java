package org.andengine.extension.scripting.opengl.texture.bitmap;

public class BitmapTextureFormatProxy {
    public static native void nativeInitClass();
}
