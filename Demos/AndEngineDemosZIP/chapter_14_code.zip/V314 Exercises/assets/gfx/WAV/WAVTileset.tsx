<?xml version="1.0" encoding="UTF-8"?>
<tileset name="WAVTileset" tilewidth="32" tileheight="32" spacing="2" margin="2">
 <image source="gfx/WAV/WAVTileSet .png" width="256" height="64"/>
 <tile id="4">
  <properties>
   <property name="coffin" value="true"/>
  </properties>
 </tile>
</tileset>
