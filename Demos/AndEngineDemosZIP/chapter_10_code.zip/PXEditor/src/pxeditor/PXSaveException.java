/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pxeditor;

/**
 *
 * @author rick
 */
public class PXSaveException extends Exception {
		// ===========================================================
		// Constants
		// ===========================================================

		//private static final long serialVersionUID = -8295358631698809883L;

		// ===========================================================
		// Fields
		// ===========================================================

		// ===========================================================
		// Constructors
		// ===========================================================

		public PXSaveException() {
			super();
		}

		public PXSaveException(final String pDetailMessage, final Throwable pThrowable) {
			super(pDetailMessage, pThrowable);
		}

		public PXSaveException(final String pDetailMessage) {
			super(pDetailMessage);
		}

		public PXSaveException(final Throwable pThrowable) {
			super(pThrowable);
		}

		// ===========================================================
		// Getter & Setter
		// ===========================================================

		// ===========================================================
		// Methods for/from SuperClass/Interfaces
		// ===========================================================

		// ===========================================================
		// Methods
		// ===========================================================

		// ===========================================================
		// Inner and Anonymous Classes
		// ===========================================================

}
